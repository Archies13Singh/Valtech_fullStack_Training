import * as React from 'react';
import { Text, View, StyleSheet,Platform } from 'react-native';
import {useState} from 'react'
export default function App() {
  let [btncol, setbacred] = useState("black")
  let bckColor = (btncol)=>{
    setbacred(btncol)
  }
  return (
    <View style={[styles.container,{backgroundColor:btncol}]}>
      <Text onPress = {()=>{bckColor("red")}} style={styles.box1}></Text>
      <Text onPress = {()=>{bckColor("green")}}  style={styles.box2}></Text>
      <Text onPress = {()=>{bckColor("orange")}}style={styles.box3}></Text>
      <Text onPress = {()=>{bckColor("blue")}}style={styles.box4}></Text>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:"row",
    alignItems:"flex-end",
    paddingTop : Platform.OS == 'android' ? 20:0,
  },
  box1 :{
    flex : 2.5,
    backgroundColor : "red",
    width : 82,
    height : 82
  },
  box2 :{
    flex : 2.5,
    backgroundColor : "green",
    width : 82,
    height : 82
  },
  box3 :{
    flex : 2.5,
    backgroundColor : "orange",
    width : 82,
    height : 82
  },
  box4 :{
    flex : 2.5,
    backgroundColor : "blue",
    width : 82,
    height : 82
  }
});