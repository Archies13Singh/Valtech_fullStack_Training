import { useState } from "react";
import antman from "./assets/images/antman.jpg"
import blackpanther from "./assets/images/blackpanther.jpg"
import horse from "./assets/images/horse.png"
import ironman from "./assets/images/ironman.jpg"
import { ActivityIndicator, Button, Text,View,StyleSheet, Platform,Image } from "react-native";
export default function App(){

  let [name,updateName] = useState({title:'',firstname:'',lastname:'',image:''})
  let updateHero=(e)=>{
    if(e==="antman"){
      updateName({
        title:"Antman",
        firstname:"Scot",
        lastname:"Lang",
        image:antman
      })
    }
    else if(e==="blackpanther"){
      updateName({
        title:"BlackPanther",
        firstname:"T",
        lastname:"Challa",
        image:blackpanther
      })
    }
    else if(e==="horse"){
      updateName({
        title:"Antman",
        firstname:"XYZ",
        lastname:"LMN",
        image:horse
      })
    }
    else{
      updateName({
        title:"ironman",
        firstname:"Edward",
        lastname:"Stark",
        image:ironman
      })
    }
  }
  return(    
    <View style={mystyle.container}>

      <View>
        <Text style={{fontSize:42}}>Heros App</Text>
      </View>
      <Text/>
      <View style={{borderColor:'blue',borderBottomWidth:1,borderTopWidth:1}}>
        <Text style={{fontSize:32}}>
        Title : {name.title}{"\n"}  
        Firstname: {name.firstname}{"\n"}
        Lastname: {name.lastname}</Text>
        <Image source={name.image}></Image>
        <Text/>
      </View>

      <View style={mystyle.buttons}>
        <Button onPress={()=>updateHero("antman")} title="Antman"></Button>
        <Button onPress={()=>updateHero("blackpanther")} title="BlackPanther"></Button>
        <Button onPress={()=>updateHero("horse")} title="Horse"></Button>
        <Button onPress={()=>updateHero("ironman")} title="IronMan"></Button>

      </View>

     </View>
   
  )
}
let mystyle = StyleSheet.create({
  container:{
    flex:1,
    justifyContent:'center',
    alignItems:'center',
    paddingTop: Platform.OS ==="android"?30:0,
    backgroundColor:"#F2A304"
  },
  buttons:{
    flex:1,
    alignItems :"space-evently",
    gap : 34,
    flexDirection:"column-reverse",

  }
})