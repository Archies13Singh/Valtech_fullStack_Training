import { Component } from "react";
import GridComp from "./grid.component";
 
class App extends Component{
    state = {
        apptitle : "User's List",
       
    }
   
    render(){
        return <div className="container">
                <h1>{this.state.apptitle}</h1>
                <GridComp/>
               </div>
    }
}
 
export default App;
 
