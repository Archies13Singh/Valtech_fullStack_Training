import { Component } from "react";
import axios from "axios"
 
class GridComp extends Component{
    state = {
        users : []
       
    }



    loaddata = ()=>{
        axios.get("https://reqres.in/api/users?page=2").then(res=>{
            this.setState({
                users : res.data.data
            })
        })
    }
    componentDidMount(){
        this.loaddata()
    }
   
    render(){
        return <div>
            <select name="" id="">
            <option value="">Page 1</option>
            <option value="">Page 2</option>
            </select>
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">Sr #</th>
                    <th scope="col">avatar</th>
                    <th scope="col">firstname</th>
                    <th scope="col">lastname</th>
                </tr>
                </thead>
                <tbody>
                    {
                        this.state.users.map((val,idx)=>{
                            return <tr>
                                <th scope="row" key={val.id}>{idx+1}</th>
                                <td>
                                    <img src={val.avatar} alt={val.first_name} style ={{"width" : "80px"}} />
                                </td>
                                <td>{val.first_name}</td>
                                <td>{val.last_name}</td>
                            </tr>
                        })
                    }
                </tbody>
            </table>
        </div>
    }
}
 
export default GridComp;
 
