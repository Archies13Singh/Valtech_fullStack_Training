import { Component } from "react";
import PopUp from "./popup.component";

 
class App extends Component{
    state = {
        title : "These is from popUp",
        togglePop : false,
    }

    togglePopUp = ()=>{
        this.setState({
            togglePop : !this.state.togglePop
        })
    }

    changeTitle = ()=>{
        this.setState({
            title : "Hello this is PopUp"
        })
    }
    render(){

        return <div>
            <h1>App Component</h1>
            {this.state.togglePop ?
            
                <PopUp>
                    <div>
                        <h2>Pop Up Window</h2>
                        <p>
                            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque nesciunt, reprehenderit deserunt sint amet doloribus ullam quia sapiente nam iste enim quod, molestiae voluptas aut nihil, commodi consequuntur quo harum ratione tempore velit inventore? Veritatis ipsum minus deserunt, reprehenderit molestias dicta voluptatibus facere similique expedita rem ab suscipit sit optio nemo harum eligendi praesentium provident repellat ut commodi ea adipisci?
                        </p>
                        <button onClick={this.togglePopUp}>Hide Pop Up Window</button>
                        <button onClick={this.changeTitle}>Change Title</button>
                    </div>
                </PopUp> :<button onClick={this.togglePopUp}>Show Pop Up</button>
            }
            


        </div>
    }
}
 
export default App;