import { useState } from "react"

let UseStateComp = ()=>{
    let [hero, setHero] = useState({firstname : "", lastname :""});

    // let addFirstName = (evt)=>{
    //     setHero({
    //         ...hero,
    //         firstname : evt.target.value
    //     })
    // }
    // let addLastName = (evt)=>{
    //     setHero({
    //         ...hero,
    //         lastname : evt.target.value
    //     })
    // }
    

    let addHero = (evt)=>{

        setHero({
            ...hero,
            [evt.target.title] : evt.target.value
        })
    }
    return <div>
        <h1>User State Hook Component</h1>
        <h3>Firstname : {hero.firstname}</h3>
        <h3>Lastname : {hero.lastname}</h3>
        <label   htmlFor="fname">FirstName<input title="firstname" onChange={(evt)=>addHero(evt)} type="text" />
        </label><label   htmlFor="lname">Lastname<input title="lastname" onChange={(evt)=>addHero(evt)} type="text" /></label>

    </div>
}
export default UseStateComp