import { Component } from "react";
import ErrorBoundary from "./ErrorBoundry";
import HeroComp from "./Herocomp";

 
class App extends Component{
    state = {
        title : "ErrorBoundries",
    }

  
    render(){

        return <div>
            <h1>{this.state.title}</h1>
            <ErrorBoundary> <HeroComp power={Math.round(Math.random()*10)}/></ErrorBoundary>
            <ErrorBoundary> <HeroComp power={Math.round(Math.random()*10)}/></ErrorBoundary>
            <ErrorBoundary> <HeroComp power={Math.round(Math.random()*10)}/></ErrorBoundary>
            <ErrorBoundary> <HeroComp power={Math.round(Math.random()*10)}/></ErrorBoundary>
            <ErrorBoundary> <HeroComp power={Math.round(Math.random()*10)}/></ErrorBoundary>
            <ErrorBoundary> <HeroComp power={Math.round(Math.random()*10)}/></ErrorBoundary>
        </div>
    }
}
 
export default App;