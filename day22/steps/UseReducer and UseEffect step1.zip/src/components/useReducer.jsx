import { useReducer } from "react";


let UseReducer = ()=> {
    /*  
    let [power, setPower] = useState(0);
     let [version, setVersion] = useState(0);
     let [rating, setRating] = useState(0); 
     */
    let reduceFun = (state, action)=>{
        switch(action.type){
            case "Update_FirstName" :return({
                ...state,firstname:"Archies"
            })
            case "Update_LastName" :return({
                ...state,lastname:"Singh"
            })

            default : return state
        }
    }
    let [state, dispatch] = useReducer(reduceFun,{firstname:"", lastname :""})

     
     return <div>
                 <button onClick={()=>dispatch({type : "Update_FirstName"})}>Firstname</button>
                 <p>firstname :{state.firstname}</p>
                 <button onClick={()=>dispatch({type : "Update_LastName"})}>Lastname</button>
                 <p>lastname : {state.lastname}</p>
             </div>
 }
 
  
 export default UseReducer