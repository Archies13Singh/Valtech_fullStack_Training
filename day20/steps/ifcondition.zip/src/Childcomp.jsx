import { Component } from "react";

class Childcomp extends Component{
    
}


export default Childcomp;
