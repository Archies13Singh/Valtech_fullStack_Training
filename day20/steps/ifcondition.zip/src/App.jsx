import { Component } from "react";

class App extends Component{

    state = {
        condition : false
    }

    changeDefault = ()=>{
        this.setState(function(currentState, currentProp){
            return{
                condition : !this.state.condition
            }
        },
        function(){
            console.log(this.state.condition)
        })
    }

    render(){
        return<div>
            <label htmlFor="condition"> Show Terms and Conditions
                <input type="checkbox" onChange={this.changeDefault}  name="condition" id="condition" />
            </label>
            {this.state.condition && <fieldset>
                <legend>Terms & Conditions</legend>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Tempore ab hic distinctio, maxime delectus molestias voluptates quia nostrum est rem eveniet, animi voluptate consequuntur dolores ut doloribus ex totam, praesentium et aut? Recusandae, quas.</p>
            </fieldset>}
        </div>
    }
}



export default App;