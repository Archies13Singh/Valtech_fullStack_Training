import { Component } from "react";



let WithPower = (ObjectPow)=>{
    return class ObjWithPower extends Component{
        state = {
            power : 0,
            version : 0
        }
    
    
        increasePower = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }

        increaseVersion = ()=>{
            this.setState({
                version : this.state.version + 2
            })
        }
    
        render(){
            // return <ObjectPow power={this.state.power} version = {this.state.version} increasePower={this.increasePower} increaseVersion ={this.increaseVersion} />
            // return <ObjectPow {...this.state} increasePower={this.increasePower} increaseVersion ={this.increaseVersion} />
            return <ObjectPow {...this.props} {...this.state} increasePower={this.increasePower} increaseVersion ={this.increaseVersion} />
            // ...this.props will give the value of attributes that we passes in app.jsx like city and title, ...this.state will give access to all the attributes of states
        }
    }
}

export default WithPower