import { Component } from "react";
import WithPower from "./withpower";


class PowerClick extends Component{

    


    render(){
        return<div>
            <h2>Power : {this.props.power}</h2>
            <h2>Version : {this.props.version}</h2>
            <h2>Title : {this.props.title}</h2>
            <h2>City : {this.props.city}</h2>
            <button onClick={this.props.increasePower}>Increase Power</button>
            <button onClick={this.props.increaseVersion}>Increase Version</button>

        </div>
    }
}


export default WithPower(PowerClick)