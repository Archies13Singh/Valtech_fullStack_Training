import { Component } from "react";
import PowerClick from "./components/powerclick";
import PowerSlide from "./components/powerslide";


class App extends Component{
    render(){
        return<div>
            <h2>Application Component</h2>
            <PowerSlide city="Banglore" title="Something Good"/>
            <PowerClick city="Manglore" title="Something Bad"/>
        </div>
    }
} 


export default App