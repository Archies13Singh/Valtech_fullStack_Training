import React from "react";
import { Component } from "react";

class Childcomp extends Component{

    elm = React.createRef()
     
    state = {
        
        tempmessage : "temp Message"
    }
    
    render(){
        return <div>

            <h2>Child Power : {this.props.power}</h2>
            <label htmlFor="">Using event</label>
                <input type="text" onChange={(evt)=>this.props.title(evt.target.value)}/>

            <label htmlFor="">Using Reference</label>
                <input type="text" ref={this.elm} onChange={()=>this.props.title(this.elm.current.value)}/>

            <label htmlFor="">Using State</label>
                <input type="text" onBlur={(evt)=>this.setState({tempmessage : evt.target.value})}/>
                <button onClick={()=>this.props.title(this.state.tempmessage)} >Change Title</button>
            
            
            
            {/* onclick change the title */}
            {/* <button onClick={()=>this.props.title(this.state.title)} >Change Title</button> */}


        </div>
    }
}


export default Childcomp;
