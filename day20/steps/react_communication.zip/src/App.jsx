import { Component } from "react";
import Childcomp from "./Childcomp";

class App extends Component{

    state = {
        power : 0,
        title : "Component Communication"
    }

    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }

    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }

    changeTitle = (ntitle)=>{
        this.setState({
            title : ntitle
        })
    }


    render(){
        return<div>
            <h1>{this.state.title}</h1>
            <h2>Power : {this.state.power}</h2>
            
            <button onClick={this.increasePower}>Increase</button>
            <button onClick={this.decreasePower}>Decrease</button>
            <Childcomp power={this.state.power} title={this.changeTitle}/>

        </div>
    }
}



export default App;