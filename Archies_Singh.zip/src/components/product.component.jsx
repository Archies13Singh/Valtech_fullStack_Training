import { useEffect } from "react"
import { useState } from "react"
import axios from "axios"

var nameHero = new Array([])
var priceHero = new Array([])
var total=0

let Product =()=>{

        let [heroes, setHeroes] = useState([])
        let [nhero, createHero] = useState({_id:'', hero : '', price : ''})
        let [qty, updateQty] = useState({qty:0})
        // let [cart, updateCart] = useState({hero:'' , price:''})
        // let arrName = []
        let refresh = ()=>{
            axios.get("http://localhost:2525/data").then(res=>{
                setHeroes(res.data)
            })
        }

        useEffect(()=>{
            refresh()
         },[])


        let addHero = (hid)=>{
            // console.log(hid)
            axios.get("http://localhost:2525/edit/"+hid).then(res => {
                createHero(res.data);
                // console.log(res.data.hero)
                // updateCart(...cart,{hero:res.data.hero,price : res.data.price})
                // updateCart([...cart,{hero:res.data.hero,price : res.data.price}])
                nameHero.push(res.data.hero)
                console.log(nameHero)
                priceHero.push(res.data.price)
                total+=res.data.price*qty.qty
                console.log(total)
            })
        }

        // console.log(cart)

        let clickHandler = (evt)=>{
            updateQty({...qty,qty : Number(evt.target.value)})
        }
    
        return<div style={{display:"flex"}}>
            <div style={{display :"flex" ,gap:"2rem", flexWrap:"wrap"}}>
            {
                heroes.map((val,idx)=>{
                    return<div className="herocard" key={val.id} style={{backgroundColor : "black" , color:"white" , width:"30%", padding:"12px"}}>
                    <h2 style={{fontSize:"22px"}}>Title :{val.hero} </h2>
                    <h2 style={{fontSize:"22px"}}>Price :{val.price} </h2>
                    <div style={{display :"flex" ,gap:"2rem", flexWrap:"wrap",alignItems:"flex-end"}}>
                        <div style={{display:"flex", flexDirection:"column"}}>
                            <label htmlFor="">Quantity</label>
                                <input onChange={(evt)=>clickHandler(evt)} type="number" style={{width : "50px"}}/>
                        </div>
                        <input type="button"  value="Add  To Cart" style={{height:"32px"}} onClick={()=>addHero(val._id)} />
                    </div>
                </div>
    
                })
            }
            </div>
            <div style={{width :"50%", backgroundColor:"coral"}}>
                <h1 style={{textAlign:"center"}}>Cart</h1>
                
                {
                nameHero.map((val,idx)=>{
                    return<div>
                        <h2 style={{fontSize : "18px"}}>Product Name</h2>
                        <p>{val}</p>
                    </div>
                
                })

                
                }
                {
                priceHero.map((val,idx)=>{
                    return <div>
                    <h2 style={{fontSize : "18px"}}>Product Price</h2>
                    <p>{val}</p>
                </div>
                })

                
                }

                <div>
                    <h1>Total : {total}</h1>
                </div>
            </div>
        </div>
} 


export default Product  