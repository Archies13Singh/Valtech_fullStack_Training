import { useEffect } from "react"
import { useState } from "react"
import axios from "axios"


let Users = ()=>{
    let [heroes, setHeroes] = useState([])
    let [nhero, createHero] = useState({ hero : '', name : '', price : ''})
    let [ehero, modifyHero] = useState({ _id:'', hero : '', name : '', price : ''});
    let [toggle, toggleHandler] = useState(false);
    // read
    let refresh = ()=>{
        axios.get("http://localhost:2525/data").then(res=>{
            setHeroes(res.data)
        })
    }

    useEffect(()=>{
       refresh()
    },[])

    // create
    let addHero = ()=>{
        axios.post("http://localhost:2525/data",nhero).then(res=>{
            createHero({ hero : '', name : '', price : ''})
            refresh();
        }).catch(err => console.log("Error ", err))
    }
    let clickHandler = (evt)=>[
        createHero({...nhero,[evt.target.id]:evt.target.value})
    ]
    // delete
    let deleteHero = (hid)=>{
        axios.delete("http://localhost:2525/delete/"+hid).then(res=>refresh()).catch(err=>console.log(err))
    }


    // update
    let clickUpdateHandler = (evt)=>{
        modifyHero({...ehero, [evt.target.name] : evt.target.value})
    }
    let updateHero = ()=>{
        axios.post("http://localhost:2525/update/"+ehero._id, ehero).then(res=>{
            refresh();
            modifyHero({ _id:'', hero : '', name : '', price : ''})
            toggleHandler(false)
        }).catch(err => console.log("Error ", err))
    }

    let editHero = (hid)=>{
        axios.get("http://localhost:2525/edit/"+hid).then(res => {
            modifyHero(res.data);
            toggleHandler(true)
        })
    }
 

    return<div>
        <h2>Users List</h2>
        {!toggle &&<div>
            <h3>Create Hero</h3>
            <div className="mb-3">
                <label htmlFor="hero" className="form-label">Title</label>
                <input value={nhero.hero} onInput={(evt)=> clickHandler(evt) } className="form-control" id="hero" />
            </div>
            <div className="mb-3">
                <label htmlFor="name" className="form-label">First Name</label>
                <input value={nhero.name} onInput={(evt)=> clickHandler(evt) } className="form-control" id="name" />
            </div>
            <div className="mb-3">
                <label htmlFor="price" className="form-label">Last Name</label>
                <input value={nhero.price} onInput={(evt)=> clickHandler(evt) } className="form-control" id="price" />
            </div>
            <button onClick={addHero} type="submit" className="btn btn-primary">Submit</button>
 
        </div>}
        {
            toggle && <div>
            <h3>Update Hero</h3>
            <div className="mb-3">
                <label htmlFor="edit_hero" className="form-label">Title</label>
                <input name="hero" value={ehero.hero} onInput={(evt)=> clickUpdateHandler(evt) } className="form-control" id="edit_hero" />
            </div>
            <div className="mb-3">
                <label htmlFor="edit_name" className="form-label">First Name</label>
                <input name="name" value={ehero.name} onInput={(evt)=> clickUpdateHandler(evt) } className="form-control" id="edit_name" />
            </div>
            <div className="mb-3">
                <label htmlFor="edit_price" className="form-label">Last Name</label>
                <input name="price" value={ehero.price} onInput={(evt)=> clickUpdateHandler(evt) } className="form-control" id="edit_price" />
            </div>
            <button onClick={updateHero} type="submit" className="btn btn-primary">Update Hero</button>

        </div>
        }
        <table className="table">
            <thead> 
                <tr>
                <th scope="col">Si#</th>
                <th scope="col">Hero</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                </tr>
            </thead>
            <tbody>
                {
                    heroes.map(function(hero,idx){
                        return<tr key={hero._id}>
                        <td>{idx+1}</td>
                        <td>{hero.hero}</td>
                        <td>{hero.name}</td>
                        <td>{hero.price}</td>
                        <button onClick={()=>editHero(hero._id)}  className="btn btn-primary" style={{color:"black"}}>Edit</button>
                        <button onClick={()=>deleteHero(hero._id)}  className="btn btn-danger" style={{color:"black"}}>Delete</button>
                    </tr>
                    })
                }
            </tbody>
        </table>
    </div>
}




export default Users