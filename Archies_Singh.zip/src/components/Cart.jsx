import { Component } from "react";


let Cart = ()=>{
    
        return<div style={{width :"50%", backgroundColor:"coral"}}>
            <h1 style={{textAlign:"center"}}>Cart</h1>
            <table className="table">
                <thead>
                    <th>Product Selected</th>
                    <th>Product Total</th>
                </thead>
                <tbody>
                    
                </tbody>
            </table>
        </div>
    
}


export default Cart