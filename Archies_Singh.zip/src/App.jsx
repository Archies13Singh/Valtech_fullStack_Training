import { Component } from "react";
import Cart from "./components/Cart";
import Product from "./components/product.component";
// import Users from "./components/user.components";



class App extends Component{
    render(){
        return<div className="container">
            <h1 style={{textAlign:"center", backgroundColor:"coral", padding:"12px"}}>Avengers Store</h1>
            <div style={{display:"flex"}}>
                <Product/>
            </div>

        </div>
    }
} 


export default App  