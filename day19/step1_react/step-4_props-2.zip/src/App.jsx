import { Component } from "react";
import Hero from "./Hero";


class App extends Component{
    cartoons =["Doraemon","Kiterekshu","Ninja Hatoori","Shinchan","Bheem","Mighty Raju"];
    humans = ["Archies","Anmol","Sharan","Moulidhar","Mihir","Vijay"];
    colors = ["Yellow","Green","Blue","Pink","Orange","Purple"];
    render(){
        return <div>
            <Hero list ={this.cartoons} version = {1} title="Archies"></Hero>
            <Hero list = {this.humans} version = {2} title="Joginder"></Hero>
            <Hero list = {this.colors} version = {3} title="Kulvinder"></Hero>
        </div>
    }
}


export default App