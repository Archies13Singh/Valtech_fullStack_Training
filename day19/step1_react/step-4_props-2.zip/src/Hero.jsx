import { Component } from "react";



class Hero extends Component{
    rating = 23
    render(){
        return <div>
            <h2>{this.props.title + " | version :- " + (this.props.version) + " | " + (this.rating)}</h2>
            <ol>
                {
                    this.props.list.map((val,idx)=>{
                        return <li key={idx}>{val}</li>
                    })
                }
            </ol>
            <button onClick={
                ()=>{
                    this.rating = this.rating+1;
                    this.forceUpdate()
                }
            }>Change Version</button>
        </div>
    }
}


export default Hero