import { Component } from "react";



class Hero extends Component{

    state = {
        title : "Default Title"
    }
    render(){
        return <div>
            <h2>Child Component</h2>
            <h3>Title : {this.state.title}</h3>
            <button onClick={()=>{
                this.setState({
                    title : "Changed"
                })
            }}>Change Title</button>
        </div>
    }


}


export default Hero