import { Component } from "react";

class App extends Component{
    render(){
        return <h1>Hello Archies REACT Here</h1>
    }
}

export default App