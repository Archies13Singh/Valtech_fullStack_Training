import { Component } from 'react';
import {createRoot} from 'react-dom/client'
// import App from './app.component'
// createRoot(document.getElementById("root")).render(<App/>)



// var humans = ["Archies", "Anmol", "Sharan"]

// var humanlist = <ol>
//     <li>{humans[0]}</li>
//     <li>{humans[1]}</li>
//     <li>{humans[2]}</li>
// </ol>


// var Humanlist = function(){  
//     let human = ["Archies", "Anmol", "Sharan"]
//     return <ol>{
//         human.map(function(val,idx){
//             return <li key={idx}>{val}</li>
//         })
// }</ol>
// }


class HumanList extends Component{
    humans = ["Archies", "Anmol", "Sharan"]
    render(){
        return <ol>{
            this.humans.map(function(val,idx){
                return <li key={idx}>{val}</li>
            })
        }</ol>
    }
}
createRoot(document.getElementById("root")).render(<HumanList/>)



