import { Component } from "react";
import Hero from "./Hero";


class App extends Component{
    cartoons =["Doraemon","Kiterekshu","Ninja Hatoori","Shinchan","Bheem","Mighty Raju"];
    humans = ["Archies","Anmol","Sharan","Moulidhar","Mihir","Vijay"];
    colors = ["Yellow","Green","Blue","Pink","Orange","Purple"];
    render(){
        return <div>
            <Hero title="Archies" power={22} version={13}></Hero>
            <Hero title="Anmol" power={23} version={15}></Hero>
            <Hero title="Sharan" power={24} version={14}></Hero>
            <Hero></Hero>
        </div>
    }
}


export default App