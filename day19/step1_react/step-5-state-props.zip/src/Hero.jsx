import { Component } from "react";
import PropTypes from 'prop-types'
// we can use proptypes library to fix the prop type to string or number

class Hero extends Component{

    /* 

    defaultProps is the library of props so not allowed to change the name
    */
    static defaultProps = {
        title : "default title",
        power : 0,
        version : 0
    }


    static propTypes = {
        title : PropTypes.string.isRequired,
        power : PropTypes.number.isRequired,
        version : PropTypes.number.isRequired
    }
    render(){
        return <div>
            <h2>Default Props</h2>
            <p>Title : {this.props.title}</p>
            <p>Power : {this.props.power}</p>
            <p>Version :{this.props.version}</p>
        </div>
    }


}
/*
we can also call default props by using class name 

Hero.defaultProps = {
    title : "default title",
    power : 0,
    version : 0
    }

*/


export default Hero