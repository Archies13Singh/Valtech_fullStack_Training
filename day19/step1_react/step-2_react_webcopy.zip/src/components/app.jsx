import { Component } from "react";
// import CardsLeft from "./cards.left";
// import CardsRight from "./cards.right";
import Footer from "./footer";
import Header from "./header";
import MainComp from "./main";
import Marketing from "./marketing";
// import Sponser from "./sponsers";


class App extends Component{

    render(){
        return <div>
            <Header/>

           <main>
            <MainComp/>
            {/* <div className="container marketing">
                    <div className="row">
                        <Sponser/>
                        <Sponser/>
                        <Sponser/>
                    </div>
            <hr class="featurette-divider"></hr>
            <CardsRight/>
            <CardsLeft/>
            <CardsRight/>
            </div> */}
            <Marketing/>
            <hr class="featurette-divider"></hr>
            <Footer/>
           </main>
        </div>
    } 
}

export default App
