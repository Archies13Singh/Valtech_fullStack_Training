import { Component } from "react";



class Hero extends Component{
    render(){
        return <div>
            <h2>{this.props.title.toLowerCase()}</h2>
            <h3>{this.props.version*2}</h3>
        </div>
    }
}


export default Hero