import { Component } from "react";
import Hero from "./Hero";


class App extends Component{
    render(){
        return <div>
            <Hero version = {1} title="Archies"></Hero>
            <Hero version = {2} title="Joginder"></Hero>
            <Hero version = {3} title="Kulvinder"></Hero>
        </div>
    }
}


export default App