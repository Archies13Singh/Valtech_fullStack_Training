import {Link} from "react-router-dom"
import data from './data/data.json'


let Home = ()=>{


    return<div style={{display : 'flex', flexWrap : "wrap"}}>
        {
            data.heroes.map((value, idx)=>{
                return<div style={{backgroundColor:'black', margin:"12px", padding : '12px'}}>
                        
                        <Link to={`/post/${value.id}`}>
                            <h2>{value.name}</h2>
                        </Link>
                        
                    </div>
            })
        }
    </div>
    
}



export default Home