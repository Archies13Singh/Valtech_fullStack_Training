import { useParams } from "react-router-dom"
import data from './data/data.json'


let Hero = (props)=>{

    const {id} = useParams();

    return<div style={{border :'2px solid grey', display:'flex', justifyContent:'center', alignItems:'center', margin:'100px auto'}}>
        {
            data.heroes.map((value, idx)=>{
                if(value.id == id){
                    return<article>
                        <h1>{value.name}</h1>
                        <h2>{value.powerstats.intelligence}</h2>
                        <h2>{value.biography.publisher}</h2>
                    </article>
                }
            })
        }
    </div>
    
}



export default Hero