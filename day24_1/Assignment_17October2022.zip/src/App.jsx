import { BrowserRouter, Routes, Route } from "react-router-dom"
import Hero from './components/HeroDetails';
import Home from './components/Home';


function App() {
    return<div className="container">
        <BrowserRouter>
            <Routes>
                <Route  path='/' element= {<Home/>}/> 
                <Route path='/post/:id' element= {<Hero/>}/> 
        </Routes>
    </BrowserRouter>
    </div>

















    // <div className='container'>
    //     <h1>Hero List</h1>
    //     {
    //         data.heroes.map((value, idx)=>{
    //             return<div>
                        
    //                     <li key={value.id}>
    //                         <NavLink to={`/${value.id}`}></NavLink>
    //                     </li>
    //                     <Routes>

    //                     </Routes>
                        
    //                 </div>
    //         })
    //     }

    // </div>


}
export default App;



